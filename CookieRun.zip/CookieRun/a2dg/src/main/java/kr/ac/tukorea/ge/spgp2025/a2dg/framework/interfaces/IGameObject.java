package kr.ac.tukorea.ge.spgp2025.a2dg.framework.interfaces;

import android.graphics.Canvas;

public interface IGameObject {
    public void update();
    public void draw(Canvas canvas);
}
